import java.util.Arrays;

class RobotControl {
	private Robot r;

	public RobotControl(Robot r) {
		this.r = r;
	}

	// Method to return the maximum element in an array
	static int largest(int arr[]) {
		int i;
		int max = arr[0];
		for (i = 1; i < arr.length; i++)
			if (arr[i] > max)
				max = arr[i];
		return max;
	}

	public void control(int barHeights[], int blockHeights[], int required[], boolean ordered) {
		int sourceHeight = Arrays.stream(blockHeights).sum();
		int blockHeight = Arrays.stream(blockHeights).sum();
		int temp[] = new int[blockHeights.length];
		int targetBlockHeight = 0;
		int maxBlockHeight = largest(blockHeights);
		int maxBarHeight = largest(barHeights);
		int tempBlockHeight = 0;
		int requiredIndex = 0;
		int tempIndex = 0;
		int blockIndex = blockHeights.length - 1;

		boolean tempPlaced = false, sourcePlaced = false, targetPlaced = true;

		int maxHeight = 0; // to determine the arm1 height
		if (maxBarHeight + maxBlockHeight > blockHeight) {
			// if the block heights is less than the total block height assign arm1 height
			// to
			// the total block height
			maxHeight = maxBarHeight + maxBlockHeight;
		} else {
			// if block heights are greater than the bar heights
			maxHeight = blockHeight;
		}
		for (int i = 0; i < maxHeight; i++) {
			r.up();
		}
		while (targetBlockHeight != blockHeight) {
			// performing the block move until the all the blocks are placed in
			// the target

			if (sourceHeight != 0 && required[requiredIndex] == blockHeights[blockIndex]) {
				// if the top block in the source is the block needed to place in the source.
				if (targetPlaced) {
					// if the lock is placed in the target place arm2 is moved to the source
					// position
					for (int i = 0; i < 9; i++) {
						r.extend();
					}
				} else {
					// move the arm2 to the source position from the temp position
					r.extend();
				}
				/*
				 * moving the arm 3 to lower down and pick the block from the source position
				 * and to place it in the target position
				 */
				for (int i = 0; i < (maxHeight - sourceHeight + 1); i++) {
					r.lower();
				}
				r.pick();
				for (int i = 0; i < (maxHeight - sourceHeight + 1); i++) {
					r.raise();
				}
				for (int i = 0; i < 9; i++) {
					r.contract();
				}
				for (int i = 0; i < (maxHeight - targetBlockHeight - blockHeights[blockIndex] + 1); i++) {
					r.lower();
				}
				r.drop();
				for (int i = 0; i < (maxHeight - targetBlockHeight - blockHeights[blockIndex] + 1); i++) {
					r.raise();
				}
				/*
				 * once the block is placed in the target position the source height is reduced
				 * the target position height is incremented since the first required block is
				 * placed the index is also incremented to check for the next blocl 3 boolean
				 * variables to keep track of where the blocks are placed
				 */
				sourceHeight -= blockHeights[blockIndex];
				targetBlockHeight += blockHeights[blockIndex];
				requiredIndex += 1;
				blockIndex -= 1;
				tempPlaced = false;
				sourcePlaced = false;
				targetPlaced = true;

			} else if (tempBlockHeight != 0 && required[requiredIndex] == temp[tempIndex - 1]) {
				/*
				 * if the reqired block is the top block of the temp position the arm is
				 * extedned upto the temp position and the block is picked and placed in the
				 * target
				 */
				if (sourcePlaced) {
					/*
					 * if the previous block is supposed to be placed in the source position from
					 * temp then one position is contracted for the arm2
					 */
					r.contract();
				} else {
					/*
					 * if the previous block is supposed to be placed in the target position from
					 * temp then it is extened to the temp position to continue the check
					 */

					for (int i = 0; i < 8; i++) {
						r.extend();
					}
				}
				for (int i = 0; i < (maxHeight - tempBlockHeight + 1); i++) {
					r.lower();
				}
				r.pick();
				for (int i = 0; i < (maxHeight - tempBlockHeight + 1); i++) {
					r.raise();
				}
				for (int i = 0; i < 8; i++) {
					r.contract();
				}
				for (int i = 0; i < (maxHeight - targetBlockHeight - temp[tempIndex - 1] + 1); i++) {
					r.lower();
				}
				r.drop();

				for (int i = 0; i < (maxHeight - targetBlockHeight - temp[tempIndex - 1] + 1); i++) {
					r.raise();
				}

				/*
				 * once the block is placed in the target position the temp height is reduced
				 * the target position height is incremented , the required block is the temp
				 * index is also decremented placed the index is also incremented to check for
				 * the next blocl 3 boolean variables to keep track of where the blocks are
				 * placed
				 */
				tempBlockHeight -= temp[tempIndex - 1];
				targetBlockHeight += temp[tempIndex - 1];
				requiredIndex += 1;
				tempIndex -= 1;
				tempPlaced = false;
				sourcePlaced = false;
				targetPlaced = true;

			} else if (sourceHeight == 0 && tempBlockHeight != 0 && required[requiredIndex] == temp[tempIndex - 1]) {
				/*
				 * if all the blocks from the source position is moved this condition executes
				 * pick the block from the temp and keep in the target position
				 */
				for (int i = 0; i < 8; i++) {
					r.extend();
				}
				for (int i = 0; i < (maxHeight - tempBlockHeight + 1); i++) {
					r.lower();
				}
				r.pick();
				for (int i = 0; i < (maxHeight - tempBlockHeight + 1); i++) {
					r.raise();
				}
				for (int i = 0; i < 8; i++) {
					r.contract();
				}
				for (int i = 0; i < (maxHeight - targetBlockHeight - temp[tempIndex - 1] + 1); i++) {
					r.lower();
				}
				r.drop();

				for (int i = 0; i < (maxHeight - targetBlockHeight - temp[tempIndex - 1] + 1); i++) {
					r.raise();
				}

				/*
				 * the block is moved from temp hence temp height is reduced target block height
				 * i incremented as required block is placed the required index is incremented
				 * and the temp index is decremented also 3 boolean variables to keep track of
				 * where the blocks are kept
				 */
				tempBlockHeight -= temp[tempIndex - 1];
				targetBlockHeight += temp[tempIndex - 1];
				sourceHeight -= temp[tempIndex - 1];
				requiredIndex += 1;
				tempIndex -= 1;
				tempPlaced = false;
				sourcePlaced = false;
				targetPlaced = true;

			} else if (sourceHeight == 0 && tempBlockHeight != 0 && required[requiredIndex] != temp[tempIndex - 1]) {
				/*
				 * if all the blocks from the source position is moved this condition executes
				 * if the required block and the top block in temp is not equal pick the block
				 * from the temp and keep in the source position
				 */
				for (int i = 0; i < 8; i++) {
					r.extend();
				}
				for (int i = 0; i < (maxHeight - tempBlockHeight) + 1; i++) {
					r.lower();
				}
				r.pick();
				for (int i = 0; i < (maxHeight - tempBlockHeight) + 1; i++) {
					r.raise();
				}
				r.extend();
				for (int i = 0; i < (maxHeight - temp[tempIndex - 1]) + 1; i++) {
					r.lower();
				}
				r.drop();
				for (int i = 0; i < (maxHeight - temp[tempIndex - 1]) + 1; i++) {
					r.raise();
				}

				/*
				 * the block is moved from temp hence temp height is reduced source block height
				 * is incremented as the block is placed int the source position required index
				 * is incremented and the temp index is decremented also 3 boolean variables to
				 * keep track of where the blocks are kept
				 */

				tempBlockHeight -= temp[tempIndex - 1];
				sourceHeight += temp[tempIndex - 1];
				tempIndex -= 1;
				blockIndex += 1;
				tempPlaced = false;
				sourcePlaced = true;
				targetPlaced = true;

			} else if (sourcePlaced && sourceHeight != 0 && tempBlockHeight != 0
					&& required[requiredIndex] != temp[tempIndex - 1]) {
				/*
				 * this condition executes when the source height and the tempHeight is not
				 * empty and the top block in the temp position is not the requird block to be
				 * placed on the target position. Hence that block is placed in the source
				 * position
				 */
				if (sourcePlaced) {
					r.contract();
				} else {
					for (int i = 0; i < 8; i++) {
						r.extend();
					}
				}
				for (int i = 0; i < Math.abs(maxHeight - tempBlockHeight) + 1; i++) {
					r.lower();
				}
				r.pick();
				for (int i = 0; i < (maxHeight - tempBlockHeight) + 1; i++) {
					r.raise();
				}
				r.extend();
				for (int i = 0; i < (maxHeight - temp[tempIndex - 1] - sourceHeight) + 1; i++) {
					r.lower();
				}
				r.drop();
				for (int i = 0; i < (maxHeight - temp[tempIndex - 1] - sourceHeight) + 1; i++) {
					r.raise();
				}
				/*
				 * onece the block has been placed in the source position, the height of the tep
				 * position is decremented and increasing the source height by the block placed
				 * on it. And 3 boolean variables to keep tract of where the blocks are placed
				 */
				tempBlockHeight -= temp[tempIndex - 1];
				sourceHeight += temp[tempIndex - 1];
				tempIndex -= 1;
				blockIndex += 1;
				tempPlaced = false;
				sourcePlaced = true;
				targetPlaced = true;
			}

			else if (sourceHeight != 0 && required[requiredIndex] != blockHeights[blockIndex]) {
				/*
				 * if the source position top block is not equal to the requird block then it is
				 * placed in the temp position
				 */
				if (tempPlaced) {
					r.extend();
				} else {
					for (int i = 0; i < 9; i++) {
						r.extend();
					}
				}
				for (int i = 0; i < (maxHeight - sourceHeight + 1); i++) {
					r.lower();
				}
				r.pick();

				for (int i = 0; i < (maxHeight - sourceHeight + 1); i++) {
					r.raise();
				}
				r.contract();
				for (int i = 0; i < (maxHeight - tempBlockHeight - blockHeights[blockIndex] + 1); i++) {
					r.lower();
				}
				r.drop();
				for (int i = 0; i < (maxHeight - tempBlockHeight - blockHeights[blockIndex] + 1); i++) {
					r.raise();
				}
				/*
				 * once the block has been placed in the temp position, the height of the tep
				 * position is increased and decreasing the source height by the block removed
				 * from it.
				 */
				sourceHeight -= blockHeights[blockIndex];
				temp[tempIndex] = blockHeights[blockIndex];
				tempBlockHeight += blockHeights[blockIndex];
				blockIndex -= 1;
				tempIndex += 1;
				tempPlaced = true;
				sourcePlaced = false;
				targetPlaced = false;
			}
		}
	}
}